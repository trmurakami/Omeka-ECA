<?php echo $this->terms; ?>
